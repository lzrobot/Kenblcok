/**
 * \著作权  Copyright (C), 2016-2020, LZRobot
 * @名称：  Kenblock_BD_36.h
 * @作者：  Kenblcok
 * @版本：  V0.1.1
 * @时间：  2019/7/04
 * @描述：  水下推进器驱动模块驱动程序库。有IIC和USART两种通信方式。
 *
 * \说明
 * 水下推进器驱动模块驱动程序库。有IIC和USART两种通信方式。使用方式详见 motor 函数注释 和 示例程序。
 *
 * \方法列表
 * 		void 	begin(); 	// 通信初始化
 * 		void	motorRun(uint8_t index1,int16_t speed1,uint8_t index2,int16_t speed2,uint8_t index3,int16_t speed3,uint8_t index4,int16_t speed4)
				//电机控制函数。同时控制 1个、2个、3个或者4个电机转速。电机序号只能是1~4，否则不执行。
 * 		void 	motorStop(uint8_t index);				// 控制电机停止。电机序号只能是1~4，否则不执行。
 * 		int		getMotorVelocity(uint8_t index); 		// 获取电机的转速，返回电机速度值。
 * 		void	getMotorVelocity(int *IIC_Velocity);	// 获取电机的转速，返回电机速度值。
 *
 * \修订历史
 * `<Author>`      `<Time>`        `<Version>`        `<Descr>`
 *  Jimmy           2019/7/04      0.1.0              新建库文件。
 *  
 * \示例
 *  
 * 		1.ExMotorTest.ino 	// 电机舵机控制模块：电机使用示例。
 */
#ifndef Kenblock_BD_36_h
#define Kenblock_BD_36_h

#include <Arduino.h>
#include <stdio.h>
#include <Wire.h>

// 使用软件串口
// 如果要使用硬件串口，需要注释掉此条
#define BD_36_USE_SOFTWARE_SERIAL

#ifdef BD_36_USE_SOFTWARE_SERIAL
#include "SoftwareSerial.h"
#endif

// 电机舵机驱动模块 IIC地址 （STM32 地址为0x08）
#define BD_36_ADDRESS   0x04 

// 电机舵机驱动模块 电机接口定义
#define M1  (1)
#define M2  (2)
#define M3  (3)
#define M4  (4)


/**
 * Class: BD_36
 * \说明：Class BD_36 的声明
 */
class BD_36
{
  public:
	
	BD_36(void);
	void motorRun(uint8_t index1,int16_t speed1,uint8_t index2 = 0,int16_t speed2 = 0,uint8_t index3 = 0,int16_t speed3 = 0,uint8_t index4 = 0,int16_t speed4 = 0);
	void motorStop(uint8_t index);
	
	int  getMotorVelocity(uint8_t index); 
	void getMotorVelocity(int *IIC_Velocity);   
	
	virtual void datasend(uint8_t *data, uint8_t length); //virtual关键字：虚拟函数,可在派生类中改写
	virtual void datareceive(uint8_t *velocity);

  private:
	int uint8Toint16(uint8_t data_H,uint8_t data_L) ;	
  	
};


/**
 * Class: BD_36_USART
 * \说明：Class BD_36_USART 的声明
 */
class BD_36_USART : public BD_36 
{
  public: 
  
#ifdef BD_36_USE_SOFTWARE_SERIAL
	BD_36_USART(SoftwareSerial &uart, uint32_t baud = 19200);
#else 
	BD_36_USART(HardwareSerial &uart, uint32_t baud = 19200);
#endif

	void begin(uint32_t baud = 19200);

	void datasend(uint8_t *data, uint8_t length);
	void datareceive(uint8_t *velocity);
	void rx_empty(void);
	
#ifdef BD_36_USE_SOFTWARE_SERIAL
    SoftwareSerial *m_puart; /* 软件串口通信 */
#else
    HardwareSerial *m_puart; /* 硬件串口通信 */
#endif
};


/**
 * Class: BD_36_IIC
 * \说明：Class BD_36_IIC 的声明
 */
class BD_36_IIC : public BD_36 
{
  public: 
	BD_36_IIC(void);
	
	void begin(void);

	void datasend(uint8_t *data, uint8_t length);
	void datareceive(uint8_t *velocity);
};

#endif // Kenblock_BD_36_h
