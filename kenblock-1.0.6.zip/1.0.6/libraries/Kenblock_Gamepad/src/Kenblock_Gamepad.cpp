/**
 * \著作权 Copyright (C), 2016-2020, LZRobot
 * @名称：  Kenblock_Gamepad.cpp
 * @作者：  Kenblock
 * @版本：  V0.4.4
 * @时间：  2017/12/15
 * @描述：  2.4G遥控手柄 Kenblock_Gamepad.cpp。
 *
 * \说明
 * 2.4G 遥控手柄。
 *
 * \方法列表
 * 
 * 		1. void GamePad::begin(uint32_t baud = 9600)
 * 		2. void GamePad::dataRead(uint8_t id)
 *		3. void GamePad::dataRead()
 * 		4. bool GamePad::NewButtonState()
 * 		5. bool GamePad::NewButtonState(unsigned int)
 * 		6. bool GamePad::ButtonPressed(unsigned int button)
 * 		7. bool GamePad::ButtonReleased(unsigned int button)
 * 		8. bool GamePad::Button(uint16_t button)
 *		9. bool uint8_t Joystick(uint8_t joystick);
 * \修订历史
 * `<Author>`      `<Time>`        `<Version>`           `<Descr>`
 *  RJK            2017/12/15         0.4.4              新建库文件。
 *  
 * \示例
 *  
 * 		1.SoftwareSerialTest.ino
 * 		1.HardwareSerialTest.ino
 */
#include "Kenblock_Gamepad.h"

#ifdef GamePad_USE_SOFTWARE_SERIAL
GamePad::GamePad(SoftwareSerial &uart): m_puart(&uart)
{

}
#else
GamePad::GamePad(HardwareSerial &uart): m_puart(&uart)
{

}
#endif

	/**
	* \函数：begin
	* \说明：初始化接收器波特率
	* \输入参数：
    *	baud -- 波特率
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
void GamePad::begin(uint32_t baud)
{
    m_puart->begin(baud);
	//mySerial.begin(9600);
    rx_empty();
}

/**
 * \函数： rx_empty
 * \说明： 清除串口接收缓存器中的值
 */
void GamePad::rx_empty(void) 
{
    while(m_puart->available() > 0) {
        m_puart->read();
    }
}

	 /**
	* \函数：dataRead
	* \说明：按键键值读取、转换函数
	* \输入参数：
    *	id -- 接收器主板的ID
	* \输出参数：无
	* \返回值：无
	* \其他：无
	*/
void GamePad::dataRead(uint8_t id)
{	   
	//if(RXFlag == 0) last_buttons = buttons; //如果串口未收到 新数据，则状态认为是未改变
	last_buttons = buttons;
	while (m_puart->available() > 0)
	{	
		Rxdata = m_puart->read();
		if(!RXFlag)
		{
			if(Rxdata == 0xaa)
			{
				RXFlag = true;
				RE_COUNT = 0;
				*cmdbuffer = 0;
			}
		}
		if(RXFlag)
		{
			cmdbuffer[RE_COUNT++] = Rxdata;
		 if(RE_COUNT>10)
			{
				buttons = 0xffff;
				RXFlag = false;
				checksum = 0;
				RE_COUNT = 0;
				return 0;
			}
		 else if ((Rxdata == 0xbb) && (RE_COUNT == 10))
			{
				checksum = 0;
				checksum = id + cmdbuffer[2] + cmdbuffer[3] + cmdbuffer[4] + cmdbuffer[5] + cmdbuffer[6] + cmdbuffer[7];
		        checksum = (uint8_t)(checksum & 0x000000ff);

				if((cmdbuffer[1] != id)||(checksum != cmdbuffer[8]))
					{
						buttons = 0xffff;
						RXFlag = false;
						checksum = 0;
						RE_COUNT = 0;
						return 0 ;
					}
				else
					{
						RXFlag = false;
						last_buttons = buttons;
						buttons = cmdbuffer[3];
						buttons = (buttons<<8) | (uint16_t)cmdbuffer[2];
					}
			}
		}
	}
}

void GamePad::dataRead()
{	   
	//if(m_puart->available() == 0) last_buttons = buttons; //如果串口未收到 新数据，则状态认为是未改变 避免主程序循环过快导致多次判断
	last_buttons = buttons;
	while (m_puart->available() > 0)
	{	
		Rxdata = m_puart->read();
		if(!RXFlag)
		{
			if(Rxdata == 0xaa)
			{
				RXFlag = true;
				RE_COUNT = 0;
				*cmdbuffer = 0;
			}
		}
		if(RXFlag)
		{
			cmdbuffer[RE_COUNT++] = Rxdata;
		 if(RE_COUNT>10)
			{
				buttons = 0xffff;
				RXFlag = false;
				checksum = 0;
				RE_COUNT = 0;
				return 0;
			}
		 else if ((Rxdata == 0xbb) && (RE_COUNT == 10))
			{
				checksum = 0;
				checksum = cmdbuffer[1] + cmdbuffer[2] + cmdbuffer[3] + cmdbuffer[4] + cmdbuffer[5] + cmdbuffer[6] + cmdbuffer[7];
		        checksum = (uint8_t)(checksum & 0x000000ff);

				if(checksum != cmdbuffer[8])
					{
						buttons = 0xffff;
						RXFlag = false;
						checksum = 0;
						RE_COUNT = 0;
						return 0 ;
					}
				else
					{
						RXFlag = false;
						last_buttons = buttons;
						buttons = cmdbuffer[3];
						buttons = (buttons<<8) | (uint16_t)cmdbuffer[2];
					}
			}
		}
	}
}

	/**
	* \函数：NewButtonState
	* \说明：获取按键是否被改变
	* \输入参数：无
	* \输出参数：无
	* \返回值：
	* \bool -- 按键状态与上次相同返回：false ** 不同：true
	* \其他：无
	*/
 bool GamePad::NewButtonState()
{	

	return ((last_buttons ^ buttons) > 0);
}
	 /**
	* \函数：NewButtonState
	* \说明：获取某个按键是否被改变
	* \输入参数：无
	* \输出参数：无
	* \返回值：
	* \bool -- 按键状态与上次相同返回：false ** 不同：true
	* \其他：无
	*/
bool GamePad::NewButtonState(unsigned int button)
{
	return (((last_buttons ^ buttons) & button) > 0);
}
	 /**
	* \函数：ButtonPressed
	* \说明：检测某个按键是否被按下
	* \输入参数：无
	* \输出参数：无
	* \返回值：
	* \bool -- 按下瞬间：true ** 否则：false
	* \其他：无
	*/
bool GamePad::ButtonPressed(unsigned int button)
{
	return(NewButtonState(button) & Button(button));
}
	 /**
	* \函数：ButtonReleased
	* \说明：检测某个按键是否松开
	* \输入参数：无
	* \输出参数：无
	* \返回值：
	* \bool -- 松开瞬间：true ** 否则：false
	* \其他：无
	*/
bool GamePad::ButtonReleased(unsigned int button)
{
	return((NewButtonState(button)) & ((~last_buttons & button) > 0));
}
	 /**
	* \函数：Button
	* \说明：检测某个按键是否被按下
	* \输入参数：无
	* \输出参数：无
	* \返回值：
	* \bool -- 按下：true ** 否则：false
	* \其他：无
	*/
bool GamePad::Button(uint16_t button)
{	
	return ((~buttons & button) > 0);
}
	 /**
	* \函数：Joystick
	* \说明：获取某个摇杆的数值
	* \输入参数：无
	* \输出参数：无
	* \返回值：
	* \uint8_t -- 摇杆的位置信息
	* \其他：无
	*/
 uint8_t GamePad::Joystick(uint8_t joystick)
{	
	return cmdbuffer[joystick];
} 
