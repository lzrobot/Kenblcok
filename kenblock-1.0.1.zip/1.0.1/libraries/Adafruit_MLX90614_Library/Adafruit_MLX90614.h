 /**
 * \著作权 Copyright (C), 2016-2020, LZRobot
 * @名称：  RoIRThermometer.cpp
 * @作者：  Kenblock
 * @版本：  V0.1.0
 * @时间：  2017/08/09
 * @描述：  非接触式测温模块驱动函数。
 *
 * \说明
 * 非接触式测温模块的驱动函数。使用传感器为 MLX90614。使用I2C 通信，I2C地址：0x5A 。
 *
 * \方法列表
 * 
 * 		1. boolean RoIRThermometer::begin(void) 
 * 		2. double RoIRThermometer::readObjectTempF(void) 
 * 		3. double RoIRThermometer::readAmbientTempF(void) 
 * 		4. double RoIRThermometer::readObjectTempC(void) 
 *      5. double RoIRThermometer::readAmbientTempC(void) 
 *      6. float RoIRThermometer::readTemp(uint8_t reg) 
 *      7. uint16_t RoIRThermometer::read16(uint8_t a) 
 *
 * \修订历史
 * `<Author>`      `<Time>`        `<Version>`        `<Descr>`
 *  King          2017/08/08      0.1.0              新建库文件。
 *  
 * \示例
 *  
 * 		1.IRThermometerTest.ino
 */

#if (ARDUINO >= 100)
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif
#include "Wire.h"


#define MLX90614_I2CADDR 0x5A

// RAM
#define MLX90614_RAWIR1 0x04
#define MLX90614_RAWIR2 0x05
#define MLX90614_TA 	0x06
#define MLX90614_TOBJ1 	0x07
#define MLX90614_TOBJ2 	0x08
// EEPROM
#define MLX90614_TOMAX 	0x20
#define MLX90614_TOMIN 	0x21
#define MLX90614_PWMCTRL 0x22
#define MLX90614_TARANGE 0x23
#define MLX90614_EMISS 	0x24
#define MLX90614_CONFIG 0x25
#define MLX90614_ADDR 	0x0E
#define MLX90614_ID1 	0x3C
#define MLX90614_ID2 	0x3D
#define MLX90614_ID3 	0x3E
#define MLX90614_ID4 	0x3F


class Adafruit_MLX90614  {
 public:
  Adafruit_MLX90614(void);
  boolean begin(void);
  uint32_t readID(void);

  double readObjectTempC(void);
  double readAmbientTempC(void);
  double readObjectTempF(void);
  double readAmbientTempF(void);

 private:
  float readTemp(uint8_t reg);

  uint8_t _addr;
  uint16_t read16(uint8_t addr);
  void write16(uint8_t addr, uint16_t data);
};

