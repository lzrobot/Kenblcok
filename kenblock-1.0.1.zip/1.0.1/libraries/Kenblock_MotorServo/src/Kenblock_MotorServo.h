/**
 * \著作权  Copyright (C), 2016-2020, LZRobot
 * @名称：  Kenblock_MotorServo.cpp
 * @作者：  Kenblcok
 * @版本：  V0.1.0
 * @时间：  2017/08/22
 * @描述：  电机舵机控制模块IIC和串口控制驱动程序
 *
 * \说明
 * 通过串口和iic两种协议，发送控制指令，控制驱动板控制电机和舵机
 *
 * \方法列表
 * 
 *    1.    MotorServo();
 *    2.    void motor_control_IIC(uint8_t number1,int16_t Velocity1);
 *    3.    void motor_control_IIC(uint8_t number1,int16_t Velocity1,uint8_t number2,int16_t Velocity2);
 *    4.    void motor_control_IIC(uint8_t number1,int16_t Velocity1,uint8_t number2,int16_t Velocity2,uint8_t number3,int16_t Velocity3);
 *    5.    void motor_control_USART(uint8_t number1,int16_t Velocity1); 
 *    6.    void motor_control_USART(uint8_t number1,int16_t Velocity1,uint8_t number2,int16_t Velocity2);
 *    7.    void motor_control_USART(uint8_t number1,int16_t Velocity1,uint8_t number2,int16_t Velocity2,uint8_t number3,int16_t Velocity3);
 *    8.    void servo_control_IIC(uint8_t number1,uint8_t position1);
 *    9.    void servo_control_IIC(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2);	
 *    10.    void servo_control_IIC(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2,uint8_t number3,uint8_t position3);
 *    11.    void servo_control_IIC(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2,uint8_t number3,uint8_t position3,uint8_t number4,uint8_t position4);
 *    12.    void servo_control_USART(uint8_t number1,uint8_t position1); 
 *    13.    void servo_control_USART(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2); 
 *    14.    void servo_control_USART(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2,uint8_t number3,uint8_t position3);
 *    15.    void servo_control_USART(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2,uint8_t number3,uint8_t position3,uint8_t number4,uint8_t position4); 
 *    16.    void Get_Velocity_IIC(uint8_t number);       
 *    17.    void Get_Velocity_USART(uint8_t number);   
 *
 * \修订历史
 * `<Author>`      `<Time>`        `<Version>`        `<Descr>`
 *  King           2017/08/22      0.1.0              新建库文件。
 *  
 * \示例
 *  
 * 
 */
#ifndef Kenblock_MotorServo_h
#define Kenblock_MotorServo_h

#include <avr/pgmspace.h>
#include <util/delay.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <Arduino.h>
#include <Wire.h>
#include "Kenblock_MotorServo.h"


class MotorServo
{
	public:
	MotorServo();
	void motor_control_IIC(uint8_t number1,int16_t Velocity1);
	void motor_control_IIC(uint8_t number1,int16_t Velocity1,uint8_t number2,int16_t Velocity2);
	void motor_control_IIC(uint8_t number1,int16_t Velocity1,uint8_t number2,int16_t Velocity2,uint8_t number3,int16_t Velocity3);
	
	void motor_control_USART(uint8_t number1,int16_t Velocity1); 
	void motor_control_USART(uint8_t number1,int16_t Velocity1,uint8_t number2,int16_t Velocity2);
	void motor_control_USART(uint8_t number1,int16_t Velocity1,uint8_t number2,int16_t Velocity2,uint8_t number3,int16_t Velocity3);
	
	void servo_control_IIC(uint8_t number1,uint8_t position1);
	void servo_control_IIC(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2);	
	void servo_control_IIC(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2,uint8_t number3,uint8_t position3);
	void servo_control_IIC(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2,uint8_t number3,uint8_t position3,uint8_t number4,uint8_t position4);
	
	void servo_control_USART(uint8_t number1,uint8_t position1); 
	void servo_control_USART(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2); 
	void servo_control_USART(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2,uint8_t number3,uint8_t position3);
	void servo_control_USART(uint8_t number1,uint8_t position1,uint8_t number2,uint8_t position2,uint8_t number3,uint8_t position3,uint8_t number4,uint8_t position4); 
	
	void Get_Velocity_IIC(uint8_t number);       
	void Get_Velocity_USART(uint8_t number);     
};
#endif //Kenblock_MotorServo_h